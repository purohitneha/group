Building a String Boot Rest API v3. 

Tutorial https://medium.com/@salisuwy/building-a-spring-boot-rest-api-part-iii-integrating-mysql-database-and-jpa-81391404046a

Check http://medium.com/@salisuwy
