export interface Group{
   groupname: string;
   groupdesc: string;
   }